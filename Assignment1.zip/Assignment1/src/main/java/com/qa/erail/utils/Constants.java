package com.qa.erail.utils;
import java.util.Arrays;
public class Constants {
public final static String ERAIL_SHEET_NAME = "StationNames";
public final static String HOME_PAGE_TITLE = "Indian Railways Enquiry PNR Status Live Status IRCTC Reservation Seats";
}
