package com.qa.erail.utils;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.NoSuchFrameException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.qa.erail.factory.DriverFactory;

public class ElementUtil {
	public WebDriver driver;
	public JavaScriptUtil jsUtil;

	public ElementUtil(WebDriver driver) {
		this.driver = driver;
		jsUtil = new JavaScriptUtil(this.driver);
	}

	public WebElement getElement(By locator) {
		WebElement element = driver.findElement(locator);
		if(Boolean.parseBoolean(DriverFactory.highlight)) {
			jsUtil.flash(element);
		}
		return element;
	}
	public List<WebElement> doGetElements(By locator) {
		return driver.findElements(locator);
	}
	
	public void doSendKeys(By locator, String value) {
		WebElement element = getElement(locator);
		element.clear();
		element.sendKeys(value);
	}
	
	public void doClick(By locator) {
		
		getElement(locator).click();
		
	}
	
	
	public String doGetText(By locator) {
		return getElement(locator).getText();
	}
	
	public boolean doIsDisplayed(By locator) {
		return getElement(locator).isDisplayed();
	}
	
	public void selectDropDownValue(By locator, String value) {
		List<WebElement> optionsList = doGetElements(locator);
		for (WebElement e : optionsList) {
			if (e.getText().equals(value)) {
				e.click();
				break;
			}
		}
	}
		
	public String selectDropDownValueByIndex(By locator, int index) {
		List<WebElement> optionsList = doGetElements(locator);
		String Val = optionsList.get(index).getText();
		return Val;
	}

	public List<String> getOptionsList(By locator) {
		List<WebElement> optionsList = driver.findElements(locator);
		List<String> optionsTextList = new ArrayList<String>();
		System.out.println(optionsList.size());
		for (WebElement e : optionsList) {
			String text = e.getText();
			System.out.println(text);
			optionsTextList.add(text);
			
		}
		return optionsTextList;

	}

	public WebElement doPresenceOfElementLocated(By locator, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(timeout));
		return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
	}

	public String waitForTitleIs(String expTitle, int timeout) {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofMillis(timeout));
		if (wait.until(ExpectedConditions.titleIs(expTitle)))
			return driver.getTitle();
		return null;
	}

}
