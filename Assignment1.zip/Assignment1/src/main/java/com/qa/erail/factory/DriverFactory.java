package com.qa.erail.factory;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Properties;


//import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;
import org.openqa.selenium.io.FileHandler;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.safari.SafariDriver;

public class DriverFactory {

	public WebDriver driver;
	public Properties prop;
	public OptionsManager optionsManager;
	public static String highlight;
	
	public static ThreadLocal<WebDriver> tlDriver = new ThreadLocal<>();
	public WebDriver init_driver(Properties prop) {

		String browserName = prop.getProperty("browser").trim();

		System.out.println("browser name is : " + browserName);
		optionsManager = new OptionsManager(prop);

		if (browserName.equals("chrome")) {
				tlDriver.set(new ChromeDriver(optionsManager.getChromeOptions()));
		} else if (browserName.equals("firefox")) {
				tlDriver.set(new FirefoxDriver(optionsManager.getFirefoxOptions()));
		} else if (browserName.equals("safari")) {
			tlDriver.set(new SafariDriver());
		}

		else {
			System.out.println("Please pass the right brower: " + browserName);
		}

		getDriver().get(prop.getProperty("url"));
		getDriver().manage().deleteAllCookies();
		getDriver().manage().window().maximize();
		return getDriver();

	}
	
	
//	private void init_remoteDriver(String browser, String browserVersion) {
//
//		System.out.println("Running test on grid server: " + browser + " version: " + browserVersion);
//
//		if (browser.equals("chrome")) {
//			DesiredCapabilities cap = DesiredCapabilities.chrome();
//			cap.setCapability("browserName", "chrome");
//			cap.setCapability("browserVersion", browserVersion);
//			cap.setCapability("enableVNC", true);
//			cap.setCapability(ChromeOptions.CAPABILITY, optionsManager.getChromeOptions());
//			try {
//				tlDriver.set(new RemoteWebDriver(new URL(prop.getProperty("huburl")), cap));
//			} catch (MalformedURLException e) {
//				e.printStackTrace();
//			}
//		} else if (browser.equals("firefox")) {
//			DesiredCapabilities cap = DesiredCapabilities.firefox();
//			cap.setCapability("browserName", "firefox");
//			cap.setCapability("browserVersion", browserVersion);
//			cap.setCapability("enableVNC", true);
//			cap.setCapability(FirefoxOptions.FIREFOX_OPTIONS, optionsManager.getFirefoxOptions());
//			try {
//				tlDriver.set(new RemoteWebDriver(new URL(prop.getProperty("huburl")), cap));
//			} catch (MalformedURLException e) {
//				e.printStackTrace();
//			}
//		}
//
//	}

	public static synchronized WebDriver getDriver() {
		return tlDriver.get();
	}

	public Properties init_prop() {
		prop = new Properties();
		FileInputStream ip = null;
		String envName = "dev";
//		String envName = System.getProperty("env");

		if (envName == null) {
			System.out.println("Running on Environmant on PROD env");
			try {
				ip = new FileInputStream("C:\\Users\\TOSHIBA\\eclipse-workspace\\Assignment1\\src\\test\\resource\\config\\config.properties");
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		} else {
			System.out.println("Running on environment: " + envName);
			try {
				switch (envName) {
				case "qa":
					ip = new FileInputStream("./src/test/resources/config/qa.config.properties");
					break;
				case "uat":
					ip = new FileInputStream("./src/test/resources/config/uat.config.properties");
					break;
				case "dev":
					ip = new FileInputStream("C:\\Users\\TOSHIBA\\eclipse-workspace\\Assignment1\\src\\test\\resource\\config\\config.properties");
					break;
				default:
					break;
				}
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
		}

		try {
			prop.load(ip);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return prop;
	}
	
	public String getScreenshot() {
	String src = ((TakesScreenshot)getDriver()).getScreenshotAs(OutputType.BASE64);
	File srcFile = new File(src);
	String path = System.getProperty("user.dir")+"/screenshots/"+System.currentTimeMillis()+".png";
	File destination = new File(path);
	try {
		FileHandler.copy(srcFile, destination);
	}catch (IOException e) {
		e.printStackTrace();
	}
	return path;
	}
	
	
	
}
