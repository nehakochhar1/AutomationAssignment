package com.qa.erail.pages;

import java.io.IOException;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.qa.erail.utils.Constants;
import com.qa.erail.utils.ElementUtil;
import com.qa.erail.utils.ExcelUtil;

public class erailHomePage {
	private WebDriver driver;
	private ElementUtil elementUtil;
	
	//1. By locator
	private By fromStation = By.xpath("//input[@id='txtStationFrom']");
	private By fromStationList = By.xpath("(//div[@class='autocomplete'])[1]/div");
	private By SelectSortOnDate = By.cssSelector("[title='Select Departure date for availability']");
	private By Select30DaysFromTheCurrentDate = By.xpath("(xpath=\"(//td[@onclick])[31]\")");
	
	
	//2. Constructor
	public erailHomePage(WebDriver driver) {
		this.driver = driver;
		elementUtil = new ElementUtil(this.driver);
	}
	
	//3. page actions

	//@Step("getting Home page title...")
	public String getHomePageTitle() {
		return elementUtil.waitForTitleIs(Constants.HOME_PAGE_TITLE, 5);
	}
	
	public void ClickDropDownVal(String input_val) {
		elementUtil.doPresenceOfElementLocated(fromStation, 1000);
		elementUtil.doClick(fromStation);
		elementUtil.doSendKeys(fromStation, input_val);
//		List<WebElement> optionsList = driver.findElements(fromStationList);
	}
	
	public String selectDropDownValueByIndex(int index) {
		elementUtil.doPresenceOfElementLocated(fromStationList, 1000);
		String Value =elementUtil.selectDropDownValueByIndex(fromStationList, index);
		System.out.println("Value at 4rth index is "+ Value);
		return Value;
	}
	public void ReadWriteDataFromDropDownTOExcel() throws IOException {
		elementUtil.doPresenceOfElementLocated(fromStationList, 1000);
		List<String> optionsVal = elementUtil.getOptionsList(fromStationList);
		for (int i = 0; i < optionsVal.size(); i++) {
			System.out.println(optionsVal.get(i));
		}
		Object data[][]=ExcelUtil.getTestData(Constants.ERAIL_SHEET_NAME);
		
		//Write data to excel
	
		
		
		
	}
	
	
		
	}

//	
//	public void SelectValueFromDropdown()
//	{
//		ExcelUtilis excelUtilis = new ExcelUtilis();
//		excelUtilis.CreateNewSheet(dropdownValue);
//		dropdownValue.get(3).click();
//	}
//	
//	public void ReadDataFromDropdown()
//	{
//		 for(int i=0;i<dropdownValue.size();i++)
//		 {
//			 dropdownValue.get(i).getText();
//			 System.out.println(dropdownValue.get(i).getText());
//		 }
//		 System.out.println("the End");
//	}
//	
//	public void SelectSortOnDateFrom30Day()
//	{
//		try {
//			Thread.sleep(5000);
//		}
//		catch(Exception e) {
//			
//		}
//		SelectSortOnDate.click();
//		Select30DaysFromTheCurrentDate.click();
//		System.out.println("the End");
//	}
	
//}
