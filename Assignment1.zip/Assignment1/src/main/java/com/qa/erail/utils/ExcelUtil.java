package com.qa.erail.utils;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.List;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xssf.usermodel.*;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.apache.commons.compress.archivers.dump.InvalidFormatException;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.hssf.usermodel.*;


public class ExcelUtil {
	public static final String TEST_DATA_FILE = "./src/test/resource/testdata/eRailTestStationNames.xlsx";
	private static Workbook Workbook;
	private static XSSFSheet Sheet;
	String sheetName = Constants.ERAIL_SHEET_NAME;

	public void comparedata() {
    try
    {
        FileInputStream excellFile1 = new FileInputStream(TEST_DATA_FILE);
 //       FileInputStream excellFile2 = new FileInputStream(TEST_DATA_FILE);

        XSSFWorkbook workbook1 = new XSSFWorkbook(excellFile1);
//        XSSFWorkbook workbook2 = new XSSFWorkbook(excellFile2);

        XSSFSheet sheet1 = workbook1.getSheetAt(0);
        XSSFSheet sheet2 = workbook1.getSheetAt(1);
        if(compareTwoSheets(sheet1, sheet2))
        {
            System.out.println("\nTwo Excelsheets are Equal");
        }
        else
        {
            System.out.println("\nTwo Excelsheets are Not Equal");
        }
        excellFile1.close();
 
    }
    catch (Exception e)
    {
        e.printStackTrace();
    }
	}


public static boolean compareTwoSheets(XSSFSheet sheet1, XSSFSheet sheet2)
{
    int firstRow1 = sheet1.getFirstRowNum();
    int lastRow1 = sheet1.getLastRowNum();
    boolean equalSheets = true;
    for(int i=firstRow1; i <= lastRow1; i++)
    {
        System.out.print("___________________________");
        System.out.println("\nComparing Row "+i);
        System.out.println("___________________________");
        XSSFRow row1 = sheet1.getRow(i);
        XSSFRow row2 = sheet2.getRow(i);
        if(!compareTwoRows(row1, row2))
        {
            equalSheets = false;
            System.out.println(" Row "+i+" | Not Equal");
        }
        else
        {
            System.out.println(" Row "+i+" | Equal");
        }
    }
    return equalSheets;
    
}

public static boolean compareTwoRows(XSSFRow row1, XSSFRow row2)
{
    if((row1 == null) && (row2 == null))
    {
        return true;
    }
    else if((row1 == null) || (row2 == null))
    {
        return false;
    }
    int firstCell1 = row1.getFirstCellNum();
    int lastCell1 = row1.getLastCellNum();
    boolean equalRows = true;

    for(int i=firstCell1; i <= lastCell1; i++)
    {
        XSSFCell cell1 = row1.getCell(i);
        XSSFCell cell2 = row2.getCell(i);
        if(!compareTwoCells(cell1, cell2))
        {
            equalRows = false;
            System.err.println("Cell "+i+" | Not Equal");
        }
        else
        {
            System.out.println("Cell "+i+" | Equal");
        }
    }
    return equalRows;
}

public static boolean compareTwoCells(XSSFCell cell1, XSSFCell cell2)
{
    if((cell1 == null) && (cell2 == null))
    {
        return true;
    }
    else if((cell1 == null) || (cell2 == null))
    {
        return false;
    }
    
    boolean equalCells = false;

    if (cell1.getCellType() == cell2.getCellType())
    {
        if (cell1.getCellStyle().equals(cell2.getCellStyle()))
        {
            switch (cell1.getCellType())
            {
                case FORMULA:
                    if (cell1.getCellFormula().equals(cell2.getCellFormula()))
                    {
                        equalCells = true;
                    }
                    break;
                case NUMERIC:
                    if (cell1.getNumericCellValue() == cell2.getNumericCellValue())
                    {
                        equalCells = true;
                    }
                    break;
                case STRING:
                    if (cell1.getStringCellValue().equals(cell2.getStringCellValue()))
                    {
                        equalCells = true;
                    }
                    break;
                case BOOLEAN:
                    if (cell1.getBooleanCellValue() == cell2.getBooleanCellValue())
                    {
                        equalCells = true;
                    }
                    break;
                case ERROR:
                    if (cell1.getErrorCellValue() == cell2.getErrorCellValue())
                    {
                        equalCells = true;
                    }
                    break;
                default:
                    if (cell1.getStringCellValue().equals(cell2.getStringCellValue()))
                    {
                        equalCells = true;
                    }
                    break;
            }
        }
        else
        {
            return false;
        }
    }
    else
    {
        return false;
    }
    return equalCells;
}

		public static Object[][] getTestData(String sheetName) {
		Object data[][] = null;

		FileInputStream ip;
		try {
			ip = new FileInputStream(TEST_DATA_FILE);
			Workbook book = WorkbookFactory.create(ip);
			Sheet sheet = book.getSheet(sheetName);

			data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];

			for (int i = 0; i < sheet.getLastRowNum(); i++) {
				for (int j = 0; j < sheet.getRow(0).getLastCellNum(); j++) {
					data[i][j] = sheet.getRow(i + 1).getCell(j).toString();
				}
			}

		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (InvalidFormatException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

		return data;

	}

	public void close() throws Exception {
		// TODO Auto-generated method stub

	}

}
