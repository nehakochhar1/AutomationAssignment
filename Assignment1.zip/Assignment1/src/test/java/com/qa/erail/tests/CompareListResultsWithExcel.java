package com.qa.erail.tests;
import java.io.IOException;
import org.testng.Assert;
import org.testng.annotations.Test;
import com.qa.erail.utils.Constants;

public class CompareListResultsWithExcel extends BaseTest {
	

			
			//Compare the dopdown values in excelsheet
			//@Test
			public void ReadExcel() {
				try {
					homepage.ReadWriteDataFromDropDownTOExcel();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			

	}



