package com.qa.erail.tests;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.qa.erail.utils.Constants;

public class HomePageTest extends BaseTest {
		

		@Test
		public void homePageTitleTest() {
			String title = homepage.getHomePageTitle();
			System.out.println("Home page title is : " + title);
			Assert.assertEquals(title, Constants.HOME_PAGE_TITLE);
		}
}
