package com.qa.erail.tests;

import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.*;

import com.qa.erail.factory.DriverFactory;
import com.qa.erail.pages.erailHomePage;

public class BaseTest {
	
	public WebDriver driver;
	public DriverFactory driverFactory;
	public Properties prop;
	public erailHomePage homepage;
	
	@Parameters({"browser"})
	@BeforeTest
	public void setUp(String browserName) {
		driverFactory = new DriverFactory();
		prop = driverFactory.init_prop();
		
		if(browserName !=null) {
			prop.setProperty("browser", browserName);
		}
		
		driver = driverFactory.init_driver(prop);
		homepage = new erailHomePage(driver);
	}
	
	
	@AfterTest
	public void teardown() {
		driver.quit();
	}
	

}
