package com.qa.erail.tests;
import java.io.IOException;

import org.testng.Assert;
import org.testng.annotations.Test;
import com.qa.erail.utils.Constants;

public class DropDownSelByIndex extends BaseTest {
		
			//Select 4rth val from drop down and print it.
			@Test
			public void selectIndexValFromDropDown() {
				homepage.ClickDropDownVal("DEL");
				String Val = homepage.selectDropDownValueByIndex(3);
				Assert.assertEquals(Val, "Delhi Azadpur"+'\n'+"DAZ");			
			}
	}



